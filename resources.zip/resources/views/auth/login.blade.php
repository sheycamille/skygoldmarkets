@extends('layouts.auth')

@section('title', 'Login')

@section('content')
<main id="main" class="crypto-page">
    <div class="uk-section in-liquid-6 in-offset-top-10">
        <div class="uk-container">
            <div class="uk-grid uk-flex uk-flex-center">
                <div class="uk-width-5-1@m uk-background-contain uk-background-center-center">
                    <div class="uk-text-center">
                        <div class="mb-4 text-center">

                            <a href="{{url('/')}}"><img src="{{ asset('storage/photos/'.\App\Models\Setting::getValue('logo'))}}" alt="{{\App\Models\Setting::getValue('site_name')}}" title="" class="img-fluid auth__logo" /></a>
                            @if(Session::has('status'))
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                {{ session('status') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            @endif
                            @if ($errors->any())
                            <div class="alert alert-danger">
                                <button type="button" class="text-white close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <ul>
                                    @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                    @endforeach
                                </ul>

                            </div>
                            @endif
                        </div>

                        <div class="card ">
                            <h1 class="mt-3 text-center"> User Login</h1>
                            <form method="POST" action="{{ route('login') }}" class="mt-5 card__form">
                                @csrf
                                <div class="form-row">
                                    <div class="form-group ">
                                        <label for="email">Email address</label>
                                        <input type="email" class="form-control" name="email" value="{{ old('email') }}" id="email" placeholder="name@example.com" required>
                                    </div>
                                </div>

                                <br>
                                <div class="form-row">
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" name="password" id="password" placeholder="Enter Password" required>
                                </div>
                                <div>
                                <br>

                                <div class="form-group" style="justify-content:center">
                                    <button class="uk-button uk-button-primary uk-border-rounded" type="submit">Login</button>
                                </div>

                                <div class="mb-3 text-center">
                                    <small class="mb-2 text-center ">Forget your Password <a href="{{ route('password.request') }}" class="ml-1 link">Reset.</a> </small>
                                    <small class="text-center ">Dont have an Account yet? <a href="{{route('register')}}" class="ml-1 link">Sign up.</a> </small>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
