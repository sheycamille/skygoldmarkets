@extends('layouts.front')

@section('title', 'temp')

@section('temp-menu-item', 'active')

@section('content')
<main id="main" class="temp-page">


</main>
@endsection
