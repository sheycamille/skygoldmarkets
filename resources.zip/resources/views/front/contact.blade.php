@extends('layouts.front')

@section('title', 'Contact Us')

@section('contact-menu-item', 'active')

@section('content')
<main id="main" class="contact-us-page">

        <div class="uk-section in-liquid-6 in-offset-top-10">
            <div class="uk-container">
                <div class="uk-grid uk-flex uk-flex-center">
                    <div class="uk-width-5-6@m uk-background-contain uk-background-center-center">
                        <div class="uk-text-center">
                            <h1 class="uk-margin-remove">@lang('message.contact.contact_us')</h1>
                            <h2 class="uk-margin">@lang('message.contact.customer_service') <span class="in-highlight">5*</span> </h2>
                            <p class="uk-text-lead uk-text-muted uk-margin-small-top">@lang('message.contact.question')!</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!-- section content begin -->
        <div class="uk-section">
            <div class="uk-container">
                <div class="uk-grid uk-flex uk-flex-center">
                    <div class="uk-width-1-2@m uk-text-center">
                        <h2 class="uk-margin-small-bottom">@lang('message.contact.do_not_hesitate') <span class="in-highlight">@lang('message.contact.reach_out').</span></h2>
                        <p class="uk-text-lead uk-text-muted uk-margin-remove">@lang('message.contact.form')</p>
                    </div>
                    <div class="uk-width-1-1@m uk-margin-large-top">
                        <div class="uk-grid uk-grid-large uk-child-width-1-2@m" data-uk-grid>
                            <div>
                                <form id="contact-form" class="uk-form uk-grid-small" data-uk-grid>
                                    <div class="uk-width-1-1">
                                        <input class="uk-input uk-border-rounded" id="name" name="name" type="text" placeholder="@lang('message.contact.name')">
                                    </div>
                                    <div class="uk-width-1-1">
                                        <input class="uk-input uk-border-rounded" id="email" name="email" type="email" placeholder="@lang('message.contact.email')">
                                    </div>
                                    <div class="uk-width-1-1">
                                        <input class="uk-input uk-border-rounded" id="subject" name="subject" type="text" placeholder="@lang('message.contact.subject')">
                                    </div>
                                    <div class="uk-width-1-1">
                                        <textarea class="uk-textarea uk-border-rounded" id="message" name="message" rows="6" placeholder="Message"></textarea>
                                    </div>
                                    <div class="uk-width-1-1">
                                        <button class="uk-width-1-1 uk-button uk-button-primary uk-border-rounded" id="sendemail" type="submit" name="submit">@lang('message.contact.message')</button>
                                    </div>
                                </form>
                            </div>
                            <div>
                                <h4 class="uk-margin-remove-bottom">@lang('message.contact.submissions')</h4>
                                <p class="uk-margin-small-top">@lang('message.contact.business_plan')</p>
                                <div class="uk-flex uk-flex-middle uk-margin">
                                    <div class="uk-margin-small-right">
                                        <i class="fas fa-envelope fa-sm in-icon-wrap circle small primary-color"></i>
                                    </div>
                                    <div>
                                        <p class="uk-margin-remove"><a href="mailto:support@axeprogroup.com">support@axeprogroup.com</a></p>
                                    </div>
                                </div>
                                <div class="uk-flex uk-flex-middle uk-margin">
                                    <div class="uk-margin-small-right">
                                        <i class="fas fa-phone fa-sm in-icon-wrap circle small primary-color"></i>
                                    </div>
                                    <div>
                                        <p class="uk-margin-remove"><a href="tel:+18028519171"> (+1) 802-851-9171</a></p>
                                    </div>
                                </div>
                                <hr class="uk-margin-medium">
                                <h4 class="uk-margin-bottom">Our Office</h4>
                                <p>
                                @lang('message.contact.london_office'): 20-22 Wenlock Road, London, England, N1 7GU.
                                    <br>
                                    @lang('message.contact.canada_office'): Exchange Tower, 130 King Street West, Toronto, ON, Canada M5X 1A9
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- section content end -->

        <!-- section cta begin -->
        <div class="uk-section">
            <div class="uk-container">
                <div class="uk-grid">
                    <div class="uk-width-1-1 in-card-16">
                        <div class="uk-card uk-card-default uk-card-body uk-border-rounded">
                            <div class="uk-grid uk-flex-middle" data-uk-grid>
                                <div class="uk-width-1-1 uk-width-expand@m">
                                    <h3>Trade Like A Pro!</h3>
                                    <p>Trade CFDs on a wide range of instruments, including popular FX pairs, Futures, Indices, Metals, Energies and Shares and experience the global markets at your fingertips.</p>
                                </div>
                                <div class="uk-width-auto">
                                    <a class="uk-button uk-button-primary uk-border-rounded" href="{{ route('register') }}">Open an Account</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- section content end -->

        <!-- section compliment begin -->
        <div class="uk-section">
            <div class="uk-container">
                <div class="uk-grid">
                    <div class="uk-width-1-1 uk-flex uk-flex-center">
                        <div class="uk-width-3-4@m uk-text-center">
                            <h2 class="uk-margin-small-bottom">Compliment your trading with our exclusive tools</h2>
                            <p class="uk-text-lead uk-text-muted uk-margin-remove">AxePro clients are provided with exclusive access to trading tools, news and analysis.</p>
                        </div>
                    </div>
                    <div class="uk-grid uk-grid-large uk-child-width-1-4@m uk-margin-medium-top" data-uk-grid>
                        <div class="uk-flex">
                            <div>
                                <h3>Calender</h3>
                                <p>Economic & Earnings Calendars</p>
                            </div>
                        </div>
                        <div class="uk-flex">
                            <div>
                                <h3>Analysis</h3>
                                <p>Trading Central Technical Analysis</p>
                            </div>
                        </div>
                        <div class="uk-flex">
                            <div>
                                <h3>Reviews</h3>
                                <p>Daily market reviews from the AxePro Analyst Team</p>
                            </div>
                        </div>
                        <div class="uk-flex">
                            <div>
                                <h3>Knowledge</h3>
                                <p>Educational Resources</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- section content end -->
</main>
@endsection
