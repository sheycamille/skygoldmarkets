<!-- Stored in resources/views/child.blade.php -->
@section('sidebar')

<div class="c-sidebar c-sidebar-dark c-sidebar-fixed c-sidebar-lg-show" id="sidebar">
    <div class="c-sidebar-brand">
        <img class="c-sidebar-brand-full" src="{{ asset('front/img/axepro-group-logo.png') }}" width="118"
            height="46" alt="AxePro Logo">
        <img class="c-sidebar-brand-minimized" src="{{ asset('front/favicon.png') }}" width="118"
            height="46" alt="AxePro Logo">
    </div>
    <ul class="c-sidebar-nav">
        <li class="c-sidebar-nav-item">
            <a class="c-sidebar-nav-link" href="/dasboard">
                <i class="cil-speedometer c-sidebar-nav-icon"></i>
                Dashboard
            </a>
        </li>
        <li class="c-sidebar-nav-item">
            <a class="c-sidebar-nav-link" href="/dasboard">
                <i class="cil-user c-sidebar-nav-icon"></i>
                Manage Users
            </a>
        </li>
        <li class="c-sidebar-nav-item">
            <a class="c-sidebar-nav-link" href="/dasboard">
                <i class="cil-puzzle c-sidebar-nav-icon"></i>
                Manage D/W
            </a>
        </li>
        <li class="c-sidebar-nav-item">
            <a class="c-sidebar-nav-link" href="/dasboard">
                <i class="cil-list-rich c-sidebar-nav-icon"></i>
                MT5 Accounts
            </a>
        </li>
        <li class="c-sidebar-nav-item">
            <a class="c-sidebar-nav-link" href="/dasboard">
                <i class="cil-cursor c-sidebar-nav-icon"></i>
                Admins
            </a>
        </li>
        <li class="c-sidebar-nav-item">
            <a class="c-sidebar-nav-link" href="/dasboard">
                <i class="cil-settings c-sidebar-nav-icon"></i>
                Settings
            </a>
        </li>
    </ul>
    <button class="c-sidebar-minimizer c-class-toggler" type="button" data-target="_parent"
        data-class="c-sidebar-minimized"></button>
</div>

@endsection
