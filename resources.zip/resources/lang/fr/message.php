<?php
return [
   
    'home' => [
        'title_pt1' => 'Le Numéro un Mondial',
        'title_pt2' => 'Courtier Multi-Actifs.',
        'subtitle' => "Traitez les devises, les matières premières, les indices synthétiques et les indices boursiers à partir d'un seul compte.",
        'btn_1' => "s'enregistrer en 60 secondes",
        
        'icon' => 'Coût le plus bas',
        'icon_txt' => 'Aucun frais ni coûts cachés',
        'icon_2' => 'Instruments multiples',
        'icon_2txt' => 'Plus de 2000 instruments de commerce',
        'icon_3' => 'Premier technology',
        'icon_3txt' => 'Technologies de négociation multiples et nouvelles',
        'Trade_On_Mobile' => 'Commerce sur mobile',
        'txt_1' => "Traitez le marché des CFD en déplacement avec notre application mobile et bénéficiez d'une infrastructure de trading à très faible latence, d'une exécution des ordres primée et d'une liquidité importante",
        'Trade_world_markets' => 'Commerce des marchés mondiaux',
        'Manage_trading_accounts' => 'Gérer les comptes commerciaux',
        'payment_method' => 'Diverses méthodes de paiement',
        'latest_events' => 'Derniers événements économiques',
        'client_acount' => 'Comptes clients',
        'daily_rev' => 'Revenu moyen quotidien',

    ],
    'worlds_num1' => 'Négociez avec le premier courtier FX au monde !',
    'years_of_exl' => "Avec plus de 5 ans d'excellence et d'innovation, nous fournissons un accès de haute qualité aux marchés financiers, grâce à notre modèle d'exécution avancé. Découvrez le monde du trading en ligne avec des CFDs sur des milliers d'instruments dans 6 classes d'actifs.",
    'trade_70_major'=> 'Traitez 70 paires de devises majeures, mineures et exotiques à des conditions de négociation compétitives.',
    'metals' => 'Métaux',
    'trade_metal_comodities' => "Négociez des produits métalliques tels que l'or, l'argent et le platine",
    'trade_major_and_minor' => 'Négociez des CFDs Spot et Futures sur les indices majeurs et mineurs du monde entier',
    'Shares' => 'Actions',
    'hundreds_of_companies' => "Des centaines d'entreprises publiques des États-Unis, du Royaume-Uni, de France et d'Allemagne sont disponibles pour la négociation",
    'Cryptocurrencies' => 'Crypto-monnaies',
    'trade_bitcoin' => "Négociez des CFD de bitcoin, d'éther, de doge et d'autres crypto et altcoins",
    'discover_opportunities' => 'Découvrez les opportunités sur le pétrole brut britannique et américain, ainsi que les CFDs sur le gaz naturel au comptant et à terme',
    'read_more' => 'Lire la suite',
    'trade_with' => 'Négociez avec ',
    'world_leading' => 'le plus grand courtier',
    'broker' => 'du monde',
    'awards' => '90+ prix',
    'five_star' => 'Service 5 étoiles',
    'four_industry' => "4 règlements de l'industrie",
    'trade_like_a_pro' => 'Négociez comme un pro !',
    'trade_cdfs' => "Négociez des CFD sur un large éventail d'instruments, notamment les paires de devises les plus populaires, les contrats à terme, les indices, les métaux, les énergies et les actions, et découvrez les marchés mondiaux du bout des doigts",
    'open_acount' => 'Ouvrir un compte',
    'compliment_trading' => 'Complétez votre négociation avec nos outils exclusifs',
    'axepro_clients' => "Les clients d'AxePro bénéficient d'un accès exclusif aux outils de trading, aux nouvelles et aux analyses.",
    'calender' => 'Calendrier',
    'econs_earning' => 'Calendriers économiques et des gains',
    'analysis' => 'Analyse',
    'trading_central' => 'Trading Central Analyse technique',
    'reviews' => 'Critiques',
    'daily_market_reviews' => "Des analyses quotidiennes du marché par l'équipe d'analystes d'AxePro",
    'knowledge' => 'Connaissances',
    'education' => 'Ressources éducatives',

    'forex' => [
        'forex_trading' => 'Commerce du Forex',
        'trade_cdf_on' => "Négociez des CFD sur plus de 70 paires de devises et bénéficiez de spreads serrés et d'une exécution rapide des ordres.",
        'fx_pairs' => "Les paires de devises les plus populaires impliquent les principales devises mondiales et connaissent les volumes d'échange et la liquidité les plus élevés",

    ],
    'futures' => [
        'futures_trading' => 'commerce de contrats à terme',
        'trade_on_futures' => 'Négociez des CFD sur des contrats à terme du monde entier et explorez des possibilités de négociation infinies.',
        'futures_are' => "Les contrats à terme sont une méthode d'investissement populaire pour de nombreux traders car ils permettent de spéculer sur la valeur d'une série de produits de base, d'indices et d'énergies.",

    ],
    'indices' => [
        'spot_indices' => 'commerce sur les indices spot',
        'trade_on_indices' => "Négociez des CFD sur les indices les plus populaires d'Europe, d'Asie et d'Amérique",
        'most_popular_indices' => 'Les indices les plus populaires sont ceux qui combinent les actions de certaines des plus grandes entreprises reconnues mondialement',
        
    ],
    'shares' => [
        'shares_stocks' => 'Share & Stock trading',
        'trade_on_shares' => 'Trade CFDs on thousands of global shares and benefit from ultra-fast order execution and competitive trading conditions. Trade CFDs on shares of some of the largest and most popular companies in the US, UK, and EU',
        'most_popular_shares' => 'The most popular shares are those that combine the shares of some of the largest and globally acknowledged companies',
        
    ],
    'metals' => [
        'precious_metals' => 'Négociation de métaux précieux',
        'trade_on_metals' => 'Négociez des CFD sur les métaux au comptant et découvrez de nouvelles opportunités de négociation',
        'ndd' => "Les contrats à terme sont une méthode d'investissement populaire pour de nombreux traders car ils permettent de spéculer sur la valeur d'une série de produits de base, d'indices et d'énergies",
        
    ],
    'energies' => [
        'trade_cdf_on_energies' => 'Négociez des CFD sur les énergies',
        'trade_on_energies' => 'Négociez des CFD sur les énergies Spot telles que le pétrole Brent, le WTI et le gaz naturel et diversifiez votre portefeuille.',
        'invest_in_energies' => 'Négociez des CFD sur les énergies Spot telles que le pétrole Brent, le WTI et le gaz naturel et diversifiez votre portefeuille',

    ],
    'cryptocurrencies' => [
        'crypto' => 'Commerce des crypto-monnaies',
        'asset_class' => "Négociez la classe d'actifs la plus recherchée au monde - les crypto-monnaies - y compris le Bitcoin, l'Ethereum et le Litecoin..",
        
    ],
    'webtrader' => [
        'webtrader_title1' => 'Plate-forme de négociation',
        'webtrader_title2' => 'AxePro WebTrader',
        'webtrader_platform' => "Notre plateforme WebTrader est en train de devenir l'une des plus populaires auprès des traders.
        les traders, car elle offre un niveau supplémentaire d'analyse du marché et un accès à une
        l'accès à une profondeur de marché complète sur une interface utilisateur impressionnante et entièrement personnalisable.
        En plus de l'infrastructure de négociation avancée d'AxePro, des prix compétitifs et une exécution supérieure des ordres sans intervention du pupitre de négociation.
        l'exécution supérieure des ordres sans intervention du pupitre de négociation*, notre WebTrader
        offre l'une des expériences de trading les plus innovantes du secteur." ,
        'trde_cdfs' => ' NÉGOCIER LES CFDS SUR
        FOREX, MÉTAUX, INDICES ET ÉNERGIES - SPREADS RÉDUITS ET COMMISSIONS COMPÉTITIVES - MARCHÉ
        EXECUTION',
        'webtrader_sub' => 'WebTrader',
        'mt5_account' => 'Accédez à votre compte MT5
        directement depuis votre navigateur sans avoir à installer de logiciel',
        'indicators' => "30 indicateurs techniques et 24 outils d'analyse",
        'chart_type' => '3 types de graphiques avec 9 cadres temporels',
        'one_click' => 'Commerce en 1 clic',
        'interface' => 'Interface facile à utiliser',
        'chart_layout' => 'Mise en page personnalisable des graphiques',
        'data_transmition' => 'Transmission sécurisée des données',
        'btn_2' => 'LANCEMENT DE WEBTRADER',
        
      
    ],

    'metatrader' => [
        'metatrader_title1' => 'Plate-forme de négociation',
        'metatrader_title2' => 'MetaTrader 5',
        'fx_mt5' => "Fidèle à l'impressionnante réputation de son prédécesseur, la plateforme de négociation MT5 de FxPro vous offre tout ce dont vous avez besoin pour négocier sur les marchés financiers. MT5 est facile à utiliser et entièrement personnalisable pour s'adapter à votre style de trading, avec un environnement avancé pour le développement d'EA et des fonctionnalités supplémentaires.",
        'btn_3' => 'Commencez à négocier dès maintenant',
        'metatrader_five' => 'Metatrader 5',
        'desktop_platform' => 'Plateforme de bureau',
        'ea_trading' => "La MT5 est en train de devenir l'une des plates-formes les plus utilisées dans le secteur. Elle intègre toutes les fonctions clés qui ont été défendues pendant des années avec la MT4, mais avec quelques fonctions supplémentaires et un environnement optimisé pour le trading EA.",
        'tech_indicators' => '38+ indicateurs techniques préinstallés',
        'charting_tools' => '44 outils de graphiques analytiques',
        'frames' => '3 types de graphiques et 21 cadres temporels',
        'order' => "Types d'ordres en attente supplémentaires (limite de vente et limite d'achat)",
        'detachable' => 'Graphiques détachables',
        'from_charts' => 'Trading en 1 clic & trading à partir de graphiques',
        'trailing_stop' => 'Arrêt de suivi',
        'easy_to_use' => 'Interface facile à utiliser',
        'verification' => 'Option de vérification en 2 étapes',
        'fully_cus' => 'Graphiques entièrement personnalisables',
        'custom_eas' => 'Ajouter des EA et des indicateurs personnalisés',
        'intergrated_calender' => 'Calendrier économique intégré',
        'dom' => 'DOM(Profondeur du marché)',
        'win_mac' => 'Disponible pour Windows ou Mac',
        'download' => "Téléchargez-le gratuitement pour profiter de tous les avantages qu'il a à offrir en conjonction avec le compte de trading AxePro MT5",
        'for_win' => 'Télécharger MT5 pour Windows',
        'for_mac' => 'Télécharger MT5 pour Mac',
        'system_req' => 'Configuration requise',
        'compatible' => "Compatible avec les systèmes d'exploitation Microsoft Windows 2008/7/8/10. Vitesse Internet de 56 kbps ou plus",
        'netting' => "Le compte MT5 de FxPro est réglé par défaut sur 'Netting', ce qui signifie que les transactions sont agrégées et que la couverture n'est pas possible.",
        'hedging' => 'mais nous pouvons fournir une version "hedging" de la plate-forme sur demande.',
        'meta_for_mobile' => 'MetaTrader 5 pour mobiles et tablettes',
        'with_fxpro' => 'Avec FxPro MT5 Mobile, vous pouvez profiter de la plateforme de trading la plus populaire sur votre téléphone portable, partout et à tout moment. Disponible pour iOS et Android',
        
    ],
    'economic_calender' => [
        'calender' => 'Calendrier économique',
        'become' => 'Si vous voulez sérieusement devenir
        un trader, un plan de trading sera un élément essentiel de votre stratégie. Trouvez le calendrier économique
        économique dans nos outils FX et planifiez votre trading à la minute près en vous basant sur les rapports économiques qui doivent être publiés, les événements économiques précédents, les prévisions du consensus et les estimations.
        économiques, les événements économiques précédents, les prévisions du consensus et la volatilité estimée.
        volatilité estimée.',
        'how_to_use_calender' => 'Comment utiliser votre calendrier économiquer',
        'assist' => "Le calendrier économique FX vous aide à prendre des décisions de trading plus informées.
        décisions de trading. Jetez un coup d'œil aux événements économiques prévus pour un jour donné.
        jour donné et cliquez sur un événement individuel si vous souhaitez obtenir de plus amples informations à son sujet.
        informations à son sujet. Le temps restant jusqu'à ce qu'un événement à venir ait lieu est indiqué sur le côté gauche du calendrier économique.
        à gauche du calendrier économique, tandis que les événements passés sont marqués d'une coche",
       
    ],
    'contact' => [
        'contact_us' => 'Contactez nous',
        'customer_service' => 'Votre service clientèle',
        'question' => "Vous avez une question ou vous avez besoin d'une assistance spécialisée ? Contactez notre équipe de service clientèle qui est disponible 24 heures sur 24 et 7 jours sur 7 pour vous aider !",
        'do_not_hesitate' => "N'hésitez pas à",
        'reach_out' => 'nous contacter',
        'form' => 'Remplissez simplement le formulaire de contact ici et nous vous répondrons dans les plus brefs délais',
        'name' => 'Nom complet',
        'email' => 'Adresse électronique',
        'subject' => 'Subjet',
        'message' => 'Envoyer le message',
        'submissions' => "Soumissions d'affaires",
        'business_plan' => "Pour les soumissions de plans d'affaires. Veuillez utiliser le formulaire suivant",
        'our_office' => 'Nos bureaux',
        'london_office' => 'Notre bureau de Londres',
        'canada_office' => 'Notre bureau au Canada ',
        
    ],
    'about' => [
        'about_pt1' => 'À propos du groupe',
        'about_pt2' => 'Axepro',
        'fsa' => "Le Groupe AxePro est autorisé par la FSA des Seychelles en 2021 à agir en tant qu'intermédiaire financier et monétaire dans la conduite d'activités de courtage financier et monétaire pour la vente et l'achat de devises et l'intermédiation dans des opérations de marquage d'argent et comme autorisé avec le numéro de société 367742 Seychelles",
        'our_clients_first' => 'Faire passer nos clients en premier',
        'since' => 'depuis 2016',
        'empowering_clients' => 'Depuis environ 5 ans, nous responsabilisons nos clients en les aidant à prendre le contrôle de leur vie financière',
        'strategy' => 'Notre stratégie',
        'aim' => 'Chez AxePro Group, nous évoluons avec notre temps. Nous visons à affiner continuellement nos services pour répondre aux besoins des traders dans ce secteur très dynamique',
        'ultra_fast' => 'Exécution ultra-rapide des transactions sans intervention du dealing desk',
        'aggregation' => 'Agrégation des prix de plusieurs LPs et accès à un pool de liquidité profond',
        'research' => 'Recherche et développement continus',
        'vision' => 'Notre vision',
        'approach' => "Notre approche centrée sur le client place les besoins de ce dernier au cœur de nos opérations. Nous voulons rester parmi l'élite du secteur et conserver notre réputation de courtier le plus fiable et le plus digne de confiance",
        'accessible_trading' => 'Un trading accessible à tous grâce à des outils pédagogiques et un soutien constant',
        'constant_refinement' => "Amélioration constante de nos services pour satisfaire et dépasser les exigences de nos clients' demands",
        'ethical' => 'Adoption de pratiques commerciales éthiques et transparentes',
        'values' => 'Nos valeurs',
        'commited' => 'Nous nous engageons à créer un environnement dynamique qui fournit aux traders tous les outils nécessaires à leur expérience de trading, dans le plus grand respect de ces derniers',
        'unwavering' => "Un engagement inébranlable en faveur de la transparence, de l'excellence et de l'innovation",
        'investment_research' => 'Investissement dans la recherche et le développement',
        'business_model' => "L'expansion et l'affinement de notre modèle d'entreprise pour répondre aux besoins des commerçants",
       

    ],
    'credit_score' => [
        'what_is_credit_score' => "Qu'est-ce qu'un score de crédit ?",
        'an_assesment' => "Un score de crédit est une évaluation de la solvabilité d'un individu ou d'une entreprise afin de juger de la sécurité de la partie concernée",
        'algorithm' => "Il s'agit d'un algorithme qui estime le risque de crédit d'un débiteur potentiel (par exemple, sa capacité à payer à temps)",
        'rates' => 'Elle note les individus/entreprises sur une échelle de 0 à 100',
        'high_score' => 'Un score élevé indique un risque plus faible de défaut de paiement ou de faillite. Un score faible indique un risque plus élevé de défaut de paiement ou de faillite',
        'predict' => "Le score de crédit peut être utilisé pour prédire la probabilité de faillite d'une entreprise",
        'creditsafe' => "Creditsafe est le fournisseur le plus utilisé au monde pour les rapports de solvabilité des entreprises et maintient la plus grande base de données détenue avec plus de 240 millions d'entreprises dans le monde. 100 000 clients du monde entier ont rejoint Creditsafe pour prendre chaque jour de meilleures décisions commerciales",

    ],
    'security' => [
        'staying_safe' => 'Rester en sécurité en ligne',
        'online_security' => 'Informations importantes sur la sécurité en ligne',
        'safety' => 'Chez AxePro, la sécurité des données des clients est une priorité et nous avons mis en place des mesures de sécurité sophistiquées destinées à protéger vos informations personnelles, votre vie privée et vos fonds',
        'high_encryption' => 'Nous utilisons les niveaux les plus élevés de cryptage des données sur nos sites web et nos applications',
        'strong_team' => 'Une solide équipe de professionnels surveille en permanence et est toujours prête à réagir à tout incident ou activité irrégulière dans les paiements en ligne',
        'control' => "Nous prenons toutes les mesures nécessaires pour que le portail l'AxePro Direct soit un lieu sûr pour l'exécution de vos transactions",
        'password' => "Les mots de passe doivent être d'une certaine complexité et d'une certaine longueur",
        'update' => "Pour toute demande de mise à jour des informations personnelles/traitement de l'une de vos données personnelles, nous vérifierons que vous avez fait cette demande avant d'entreprendre toute action",
        'two_step' => 'Option de vérification en 2 étapes',
        'automated_email' => 'Confirmation automatique par courriel des modifications apportées au mot de passe de votre compte',
        'data_protection' => "Nous disposons d'un délégué à la protection des données qui veille à la conformité au GDPR et nous sommes régulièrement audités par des parties externes sur tous les contrôles que nous avons mis en place pour protéger nos systèmes et nos données",
        'online_banking' => "Lorsqu'il s'agit d'opérations bancaires et financières en ligne, il existe plusieurs précautions à prendre pour éviter les tentatives de fraude ou d'escroquerie potentielles",
        'phishing' => 'Méfiez-vous du hameçonnage',
        'phishing_emails' => "Les courriels de phishing sont une tactique courante utilisée par les fraudeurs pour obtenir des informations personnelles en se faisant passer pour une entreprise de confiance.
        en se faisant passer pour une entreprise de confiance. N'ouvrez jamais une pièce jointe ou ne cliquez jamais sur un lien dans un courriel suspect, et n'y répondez jamais. Méfiez-vous des escrocs qui utilisent des domaines de messagerie au nom similaire pour faire croire que la communication provient d'une source officielle. Bien que ce ne soit pas toujours le cas 
        ces courriels contiennent souvent des fautes d'orthographe ou un formatage incorrect qui peuvent indiquer que quelque chose ne va pas",
        'phishing_emails_pt2' => "Le phishing vocal et l'usurpation de numéros sont une autre méthode utilisée pour convaincre les victimes de divulguer des données sensibles. 
        toujours confirmer l'authenticité, même s'il s'agit d'un numéro que vous reconnaissez',
        'secure' => 'Secure Browsing",
        'Navigation sécurisée' => "Lorsque vous naviguez en ligne, vérifiez que le site Web dispose de https:// et de l'icône de cadenas sécurisé dans la barre d'URL. Méfiez-vous des 
            l'usurpation de site web, qui consiste à cloner un site web légitime et à l'utiliser pour collecter des informations sur le client, souvent par le biais d'e-mails d'hameçonnage ou de fenêtres pop-up. 
            souvent par le biais d'e-mails d'hameçonnage ou de fenêtres pop-up de navigateur",
        'secure_browsing_pt2' => "N'utilisez que des connexions Internet sécurisées et non des réseaux Wifi publics, car ces réseaux sont plus ouverts au
        piratage. Si vous utilisez un ordinateur partagé, ne sauvegardez jamais les informations de connexion et effacez le cache et les cookies après chaque session. 
        cookies après chaque session",
        'virus' => 'Virus et logiciels malveillants',
        'virus_pt1' => "Les logiciels malveillants et les virus peuvent envoyer des informations depuis votre appareil ou modifier les détails d'une transaction dans le but de voler votre identité ou vos fonds. 
        de voler votre identité ou vos fonds. Ne téléchargez pas de fichiers ou de programmes à partir de sources inconnues",
        'virus_pt2' => "Installez un logiciel anti-malware sur tous les appareils que vous utilisez et mettez-les fréquemment à jour. Vous devez également 
        vous assurer que vous disposez des dernières mises à jour du système d'exploitation sur votre appareil",
        'disclose' => 'Ne révélez pas vos données !',
        'disclose_pt1' => "Ne partagez jamais votre/vos mot(s) de passe ou les informations sensibles de votre compte avec quiconque, et ne notez jamais vos mots de passe ou codes d'accès.
        ou codes d'accès. Méfiez-vous de tout contact vous demandant de fournir des détails sur votre compte ou des informations personnelles telles que
         votre identifiant",
        'disclose_pt2' => "AxePro et d'autres sociétés de bonne réputation ne demanderont jamais de tels détails et vous devez considérer comme suspect tout contact ou demande de ce type.
        tout contact ou demande de ce type comme étant suspect",
        'easy' => 'Ne rendez pas les choses faciles',
        'easy_pt1' => "Il est parfois facile pour les fraudeurs d'utiliser un mot de passe, simplement parce qu'il n'est pas assez complexe ou qu'il n'est pas changé. Changez votre
        mot(s) de passe fréquemment et utilisez une combinaison de symboles, de chiffres, de lettres majuscules et minuscules. N'utilisez pas 
        utilisez pas de mots de passe contenant des noms de famille, des animaux domestiques ou des surnoms, car ils sont facilement devinables. Utilisez différents
         mots de passe pour différents sites web et activez l'authentification multifactorielle chaque fois que possible.",
        'for_clarity' => "Pour plus de clarté, nous tenons à souligner qu'AxePro ",
        'clarity_pt1' => "Ne fournit pas l'échange physique de, ou des services de paiement relatifs aux crypto-monnaies",
        'clarity_pt2' => "ne vous demandera jamais votre (vos) mot(s) de passe ou d'autres informations sensibles",
        'clarity_pt3' => "Ne vous demandera jamais d'effectuer des transferts vers et depuis votre compte. N'effectuez des paiements que via notre portail AxePro Direct",
        'clarity_pt4' => "Ne s'engage pas à donner des conseils en matière d'investissement ou de commerce",
        'clarity_pt5' => "Les services ne comprennent pas la gestion d'actifs ni la garantie d'un quelconque retour sur investissement",
        'fraud_pt1' => "Signalez immédiatement tout soupçon de fraude à l'agence de lutte contre la fraude en matière de cybersécurité ou aux autorités compétentes de votre juridiction",
        'fraud_pt2' => "Si vous recevez des appels, des e-mails ou des SMS non sollicités se réclamant d'AxePro, ne vous engagez dans aucune communication et signalez-le nous immédiatement via nos canaux de communication officiels sur notre site web",
        'fraud_pt3' => "Veuillez également nous informer si vous remarquez des transactions non autorisées sur votre compte ou si vous soupçonnez qu'un tiers peut avoir accès aux informations de votre compte",
        'we_remind_you' => "Nous vous rappelons de vous méfier des canaux de communication non autorisés et de ne pas divulguer de données personnelles ou d'informations de compte sensibles sur les médias sociaux",
        'we_remind_you_pt2' => "L'application mobile officielle de AxePro peut être téléchargée uniquement depuis l'App Store d'Apple et la boutique Google Play. D'autres logiciels de trading officiels fournis par nos soins sont disponibles dans notre centre de téléchargement",
        'we_remind_you_pt3' => "Veuillez vous assurer que vous utilisez uniquement des applications et des logiciels provenant de sources officielles. Si vous avez des doutes sur une application ou un canal de médias sociaux et que vous souhaitez en vérifier l'authenticité, veuillez nous contacter via l'un de nos canaux de communication officiels, que vous trouverez sur notre page de contacts.",
       
    ],
    'trading_platforms' => [
        'o_t_p' => 'Nos plateformes de négociation',
        'advanced_platform' => 'La plateforme la plus avancée au monde',
        'more_features' => "Profitez de plus de fonctionnalités avec la plateforme de trading MT5 d'AXESPRIME. AXESPRIME MT5 est la plateforme MetaTrader la plus récente et la plus avancée. Elle offre toutes les fonctions pionnières de MT4, avec en plus des outils de trading et des indicateurs plus avancés qui permettent aux traders de mieux contrôler leurs transactions et de prendre des décisions plus éclairées en utilisant des analyses de pointe.",
        'benefits' => 'Avantages et bénéfices',
        'lates_platform' => "La dernière plateforme MetaTrader offre un certain nombre d'outils analytiques et de fonctions supplémentaires conçus pour vous offrir un arsenal de négociation plus complet et une expérience améliorée, ce qui en fait l'une des meilleures plateformes disponibles sur le marché.",
        'mobile_apps' => 'Applications mobiles AXESPRIME',
        'freedom' => 'La liberté de commercer partout et à tout moment',
        'multi_awarded' => "Notre application mobile, plusieurs fois récompensée, est dotée d'une interface de trading conviviale qui vous permet de placer et de gérer vos transactions en déplacement, tout en utilisant les mêmes outils et fonctionnalités que ceux disponibles sur notre plateforme de bureau..",
        'get_started' => 'Comment commencer',
        'liquid_markets' => "Accédez à l'un des marchés les plus importants et les plus liquides au monde ! Entrez dans le monde du trading en ligne sur le Forex et les CFD en quelques étapes seulement et commencez à trader plus d'un million de dollars.",
        'world_leading' => 'des instruments sur nos plateformes de négociation de premier ordre',
        'register' => 'Enregistrez vous',
        'sign_up' => 'Inscrivez-vous et téléchargez vos documents pour vérifier votre compte.',
        'fund' => 'Fonds',
        'fund_account' => 'Une fois que vous aurez compris tous les avantages et les risques encourus, vous pourrez approvisionner votre compte.',
        'trade' => 'Commerce',
        'start_trade' => 'Commencez à négocier sur nos plateformes WebTrader, Desktop ou Mobile.',
        'withdraw' => 'Retirer',
        'withdraw_profits' => 'Retirer les bénéfices ou le solde total de votre compte à tout moment.',
        'open_an_account' => 'Ouvrir un compte',

    ],

    'trading_flexibility' => 'Flexibilité des transactions',
    'winning_platform' => 'Plateforme gagnante',
    'competitive_pricing' => 'Prix compétitifs',
    'markets' => 'Marchés',
    'sell' => 'Vendez',
    'buy' => 'Acheter',
    'change' => 'Changement',
    'platform' => 'Consultez votre plateforme pour connaître les prix les plus récents.',
    'why_trade' => 'Pourquoi faire du commerce avec AxePro?',
    'improve_result' => 'Améliorez vos résultats de négociation grâce à notre technologie de pointe',
    'best_cdf' => 'Meilleur courtier CFD.',
    'summit' => 'Sommet de TradeON 2020',
    'execution' => 'Courtier de la meilleure exécution',
    'expo' => 'Forex EXPO Dubai 2020',
    'best_platform' => 'Meilleure plateforme de négociation',
    'london_summit' => 'Sommet de Londres 2020',
    'speed' => "vitesse d'exécution*",
    'support' => 'soutien',
    'spread' => 'écart à partir de 0.0 pips',
    'instruments' => 'instruments de négociation',
    'creat_account' => 'Créer un compte',
    'discover' => 'Découvrez la plate-forme',
    'choose_platform' => 'Choisissez votre plateforme',
    'platforms' => 'Nous mettons à la disposition de nos clients un large éventail de plateformes de trading de bureau, web et mobiles, notamment la plateforme AxePro, MetaTrader 5 et cTrader.',
    'axepro_platform' => 'Plateforme AxePro',
    'start_trading' => 'Commencer à négocier',
    'six_years' => '6 years',  
    'fifthteen' => '15 years',
    'regulated' => 'UK Regulated',
    'cus_support' => 'Customer supports',
    'five_years' => '5+ Years of Excellence',
    'global_broker' => 'A Truly Global Broker',
    'growth' => 'AxePro has grown exponentially over the years and has become renowned for
     providing elite trading conditions to its clients',
    'seamless' => 'Seamless Trading Experience',
    'int_awards' => '90+ UK & International Awards',
    'our_work' => 'Our work has been repeatedly acknowledged by the industry with over 90 awards received to date for the quality of our platforms and services',
    'transparency' => 'Dedicated to transparency',
    'trusted' => 'Trusted and Fully Regulated',
    'commitment' => 'We maintain an unwavering commitment to fair and ethical trading practices',
    'best_in_class' => 'Best in Class MetaTrader Broker',   
    'all_in_one' => 'All-In-One FX Calculator',
    'precautions' => 'Précautions à prendre',
    'your_data' => 'Comment Axepro protège vos données',
    'suspicious' => 'Signaler les messages suspects dans la boîte de réception',
    'fraud' => 'Signalement immédiat des fraudes',
    'download_now' => 'Download Now',
    
];